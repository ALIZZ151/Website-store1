const produk = [
  {
    nama: "Kaos Alizz",
    harga: "Rp 50.000",
    gambar: "https://via.placeholder.com/200x200.png?text=Kaos+Alizz",
    link: "https://wa.me/628123456789?text=Halo+saya+mau+pesan+Kaos+Alizz"
  },
  {
    nama: "Topi Keren",
    harga: "Rp 30.000",
    gambar: "https://via.placeholder.com/200x200.png?text=Topi+Keren",
    link: "https://wa.me/628123456789?text=Halo+saya+mau+pesan+Topi+Keren"
  }
];

const container = document.querySelector(".produk-container");

produk.forEach((item) => {
  const card = document.createElement("div");
  card.className = "produk";
  card.innerHTML = `
    <img src="${item.gambar}" alt="${item.nama}" />
    <h3>${item.nama}</h3>
    <p>${item.harga}</p>
    <a href="${item.link}" target="_blank"><button>Beli Sekarang</button></a>
  `;
  container.appendChild(card);
});
